import { DB, uid, deepClone, getSettings } from './database.js';
import { Auth } from './auth.js';
import { Notifications, toast } from './notifications.js';

export const POSTED_STATUS = 'Posted';
export const BASE_CURRENCY = 'PKR';

const numeric = (value) => Number.isFinite(Number(value)) ? Number(value) : 0;
export const sum = (rows, selector) => rows.reduce((total, row) => total + numeric(selector(row)), 0);

export function lineBaseDebit(line) { return numeric(line.baseDebit ?? numeric(line.debit) * numeric(line.exchangeRate || 1)); }
export function lineBaseCredit(line) { return numeric(line.baseCredit ?? numeric(line.credit) * numeric(line.exchangeRate || 1)); }

export function validateJournal(lines = []) {
  const errors = [];
  if (!Array.isArray(lines) || lines.length < 2) errors.push('A journal requires at least two lines.');
  let debit = 0; let credit = 0;
  lines.forEach((line, index) => {
    const d = numeric(line.debit); const c = numeric(line.credit);
    if (!line.accountId && !line.accountCode) errors.push(`Line ${index + 1}: select an account.`);
    if (d < 0 || c < 0) errors.push(`Line ${index + 1}: amounts cannot be negative.`);
    if (d > 0 && c > 0) errors.push(`Line ${index + 1}: use debit or credit, not both.`);
    if (d === 0 && c === 0) errors.push(`Line ${index + 1}: enter a debit or credit amount.`);
    debit += lineBaseDebit(line); credit += lineBaseCredit(line);
  });
  const difference = Math.round((debit - credit) * 100) / 100;
  if (Math.abs(difference) > 0.01) errors.push(`Journal is out of balance by ${formatMoney(Math.abs(difference))}.`);
  return { valid: errors.length === 0, errors, totalDebit: debit, totalCredit: credit, difference };
}

export async function fetchContext() {
  const [accounts, projects, costCenters, users] = await Promise.all([DB.getAll('accounts'), DB.getAll('projects'), DB.getAll('costCenters'), DB.getAll('users')]);
  return { accounts, projects, costCenters, users };
}

export async function getPostedTransactions(filters = {}) {
  let rows = await DB.getAll('transactions');
  rows = rows.filter((row) => row.status === POSTED_STATUS);
  if (filters.startDate) rows = rows.filter((row) => row.date >= filters.startDate);
  if (filters.endDate) rows = rows.filter((row) => row.date <= filters.endDate);
  if (filters.projectId) rows = rows.filter((row) => row.projectId === filters.projectId || row.lines?.some((line) => line.projectId === filters.projectId));
  if (filters.costCenterId) rows = rows.filter((row) => row.costCenterId === filters.costCenterId || row.lines?.some((line) => line.costCenterId === filters.costCenterId));
  if (filters.accountCode) rows = rows.filter((row) => row.lines?.some((line) => line.accountCode === filters.accountCode));
  return rows.sort((a, b) => (b.date || '').localeCompare(a.date || ''));
}

export async function calculateBalances(filters = {}) {
  const [accounts, transactions] = await Promise.all([DB.getAll('accounts'), getPostedTransactions(filters)]);
  const map = new Map(accounts.map((account) => { const normalDebit = ['Asset', 'Expense'].includes(account.type); const opening = numeric(account.openingBalance || 0); return [account.code, { ...account, debit: numeric(account.openingDebit || 0) + (normalDebit ? opening : 0), credit: numeric(account.openingCredit || 0) + (!normalDebit ? opening : 0), directDebit: 0, directCredit: 0 }]; }));
  transactions.forEach((transaction) => transaction.lines?.forEach((line) => {
    const row = map.get(line.accountCode); if (!row) return;
    row.directDebit += lineBaseDebit(line); row.directCredit += lineBaseCredit(line);
    row.debit += lineBaseDebit(line); row.credit += lineBaseCredit(line);
  }));
  const rows = Array.from(map.values()).map((row) => {
    const normalDebit = ['Asset', 'Expense'].includes(row.type);
    const balance = normalDebit ? row.debit - row.credit : row.credit - row.debit;
    return { ...row, balance, debitBalance: row.debit, creditBalance: row.credit, currentBalance: balance };
  });
  return { accounts: rows, transactions };
}

export async function rebuildAccountBalances() {
  const { accounts } = await calculateBalances();
  await Promise.all(accounts.map((row) => DB.put('accounts', { ...row, debitBalance: row.debitBalance, creditBalance: row.creditBalance, currentBalance: row.currentBalance })));
  return accounts;
}

export function formatMoney(value, currency = BASE_CURRENCY, { compact = false, decimals } = {}) {
  const amount = numeric(value);
  const digits = decimals ?? (Math.abs(amount) >= 1000000 ? 0 : 0);
  if (compact && Math.abs(amount) >= 1000000) return `${currency} ${(amount / 1000000).toFixed(1)}M`;
  if (compact && Math.abs(amount) >= 1000) return `${currency} ${(amount / 1000).toFixed(1)}K`;
  try { return new Intl.NumberFormat('en-PK', { maximumFractionDigits: digits, minimumFractionDigits: digits }).format(amount) + ` ${currency}`; } catch { return `${amount.toLocaleString()} ${currency}`; }
}
export function formatNumber(value, digits = 0) { return numeric(value).toLocaleString('en-PK', { maximumFractionDigits: digits }); }
export function formatDate(value, options = {}) { if (!value) return '—'; const date = new Date(value); if (Number.isNaN(date.getTime())) return value; return date.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric', ...options }); }

export async function getKpis({ startDate, endDate } = {}) {
  const transactions = await getPostedTransactions({ startDate, endDate });
  const all = await getPostedTransactions();
  const accounts = await DB.getAll('accounts');
  const accountMap = new Map(accounts.map((row) => [row.code, row]));
  let income = 0; let expenses = 0; let cash = 0;
  transactions.forEach((transaction) => transaction.lines?.forEach((line) => {
    const account = accountMap.get(line.accountCode); if (!account) return;
    const debit = lineBaseDebit(line); const credit = lineBaseCredit(line);
    if (account.type === 'Revenue') income += credit - debit;
    if (account.type === 'Expense') expenses += debit - credit;
  }));
  all.forEach((transaction) => transaction.lines?.forEach((line) => {
    if (['1011', '1012', '1013', '1014', '1015', '1016', '1017'].includes(line.accountCode)) cash += lineBaseDebit(line) - lineBaseCredit(line);
  }));
  const projects = await DB.getAll('projects');
  const pending = (await DB.getAll('transactions')).filter((row) => ['Submitted', 'Under Review'].includes(row.status)).length;
  const payables = accountMap.get('2010') ? await payableTotal() : 0;
  const projectValues = await Promise.all(projects.map(async (project) => projectSummary(project.id)));
  const budgets = projectValues.reduce((total, row) => total + numeric(row.budget), 0);
  const used = projectValues.reduce((total, row) => total + numeric(row.expenses), 0);
  return { balance: cash, income, expenses, pendingApprovals: pending, supplierPayables: payables, activeProjects: projects.filter((p) => p.status === 'Active').length, totalProjectBudgets: budgets, remainingBudgets: Math.max(0, budgets - used), overBudgetProjects: projectValues.filter((p) => p.budget > 0 && p.expenses > p.budget).length, transactions, allTransactions: all, projects, projectValues };
}

export async function payableTotal() {
  const { accounts } = await calculateBalances();
  return accounts.filter((row) => row.type === 'Liability' && (row.code === '2010' || row.code.startsWith('201'))).reduce((total, row) => total + Math.max(0, row.balance), 0);
}
export async function receivableTotal() {
  const { accounts } = await calculateBalances();
  return accounts.filter((row) => row.code === '1100' || row.code.startsWith('11')).reduce((total, row) => total + Math.max(0, row.balance), 0);
}

export async function projectSummary(projectId) {
  const [project, transactions] = await Promise.all([DB.get('projects', projectId), getPostedTransactions({ projectId })]);
  if (!project) return { projectId, budget: 0, expenses: 0, income: 0, profit: 0, utilization: 0, pendingPayments: 0 };
  const accounts = await DB.getAll('accounts'); const map = new Map(accounts.map((account) => [account.code, account]));
  let expenses = 0; let income = 0;
  transactions.forEach((txn) => txn.lines?.forEach((line) => {
    const account = map.get(line.accountCode); if (!account) return;
    if (account.type === 'Expense') expenses += lineBaseDebit(line) - lineBaseCredit(line);
    if (account.type === 'Revenue') income += lineBaseCredit(line) - lineBaseDebit(line);
  }));
  const pendingPayments = (await DB.getAll('payments')).filter((payment) => payment.projectId === projectId && ['Pending', 'Submitted'].includes(payment.status)).reduce((total, payment) => total + numeric(payment.amount), 0);
  return { ...project, expenses, income, profit: income - expenses, utilization: project.budget ? (expenses / project.budget) * 100 : 0, remaining: numeric(project.budget) - expenses, pendingPayments };
}

export async function projectSummaries() { const projects = await DB.getAll('projects'); return Promise.all(projects.map((project) => projectSummary(project.id))); }

export async function getBudgetActual(budget) {
  const transactions = await getPostedTransactions({ projectId: budget.projectId, costCenterId: budget.costCenterId });
  const accounts = await DB.getAll('accounts');
  const matched = accounts.filter((account) => account.code === budget.accountCode || account.parentCode === budget.accountCode || account.code.startsWith(`${budget.accountCode}`));
  const codes = new Set(matched.map((account) => account.code));
  const actual = transactions.reduce((total, transaction) => total + (transaction.lines || []).filter((line) => codes.has(line.accountCode)).reduce((lineTotal, line) => lineTotal + lineBaseDebit(line) - lineBaseCredit(line), 0), 0);
  const utilization = budget.amount ? (actual / budget.amount) * 100 : 0;
  return { ...budget, actual, remaining: numeric(budget.amount) - actual, utilization, warning: utilization >= 100 ? 'Over Budget' : utilization >= 90 ? 'Near Budget Limit' : utilization >= 75 ? 'Attention Required' : 'Normal' };
}
export async function budgetSummaries() { const budgets = await DB.getAll('budgets'); return Promise.all(budgets.map(getBudgetActual)); }

export async function trialBalance(filters = {}) {
  const { accounts } = await calculateBalances(filters);
  return accounts.filter((row) => Math.abs(row.debitBalance) > .001 || Math.abs(row.creditBalance) > .001).map((row) => ({ ...row, debitTotal: row.debitBalance > row.creditBalance ? row.debitBalance - row.creditBalance : 0, creditTotal: row.creditBalance > row.debitBalance ? row.creditBalance - row.debitBalance : 0 }));
}
export async function incomeStatement(filters = {}) {
  const { accounts } = await calculateBalances(filters);
  const revenues = accounts.filter((row) => row.type === 'Revenue').map((row) => ({ ...row, amount: row.creditBalance - row.debitBalance })).filter((row) => Math.abs(row.amount) > .001);
  const expenses = accounts.filter((row) => row.type === 'Expense').map((row) => ({ ...row, amount: row.debitBalance - row.creditBalance })).filter((row) => Math.abs(row.amount) > .001);
  const totalRevenue = sum(revenues, (row) => row.amount); const totalExpenses = sum(expenses, (row) => row.amount);
  return { revenues, expenses, totalRevenue, totalExpenses, netProfit: totalRevenue - totalExpenses };
}
export async function balanceSheet(filters = {}) {
  const { accounts } = await calculateBalances(filters);
  const assets = accounts.filter((row) => row.type === 'Asset').map((row) => ({ ...row, amount: row.balance })).filter((row) => Math.abs(row.amount) > .001);
  const liabilities = accounts.filter((row) => row.type === 'Liability').map((row) => ({ ...row, amount: row.balance })).filter((row) => Math.abs(row.amount) > .001);
  const equity = accounts.filter((row) => row.type === 'Equity').map((row) => ({ ...row, amount: row.balance })).filter((row) => Math.abs(row.amount) > .001);
  const statement = await incomeStatement(filters);
  const totalAssets = sum(assets, (row) => row.amount); const totalLiabilities = sum(liabilities, (row) => row.amount); const totalEquity = sum(equity, (row) => row.amount) + statement.netProfit;
  return { assets, liabilities, equity, totalAssets, totalLiabilities, totalEquity, balanceDifference: totalAssets - totalLiabilities - totalEquity };
}
export async function cashFlow(filters = {}) {
  const transactions = await getPostedTransactions(filters); const accounts = await DB.getAll('accounts'); const map = new Map(accounts.map((row) => [row.code, row]));
  const cashCodes = new Set(['1011', '1012', '1013', '1014', '1015', '1016', '1017']); let inflow = 0; let outflow = 0;
  const rows = [];
  transactions.forEach((txn) => txn.lines?.forEach((line) => {
    if (!cashCodes.has(line.accountCode)) return;
    const amount = lineBaseDebit(line) - lineBaseCredit(line); const account = map.get(line.accountCode);
    if (amount >= 0) inflow += amount; else outflow += Math.abs(amount);
    rows.push({ date: txn.date, voucherNumber: txn.voucherNumber, description: txn.description, accountName: account?.name || line.accountName, amount, type: amount >= 0 ? 'Inflow' : 'Outflow', projectId: txn.projectId });
  }));
  return { rows: rows.sort((a, b) => b.date.localeCompare(a.date)), inflow, outflow, net: inflow - outflow };
}

async function audit(action, module, recordId, previousValues, newValues) {
  const user = Auth.currentUser();
  return DB.add('auditLogs', { id: uid('audit'), userId: user?.id || 'system', userName: user?.name || 'System', action, module, recordId, timestamp: new Date().toISOString(), previousValues: deepClone(previousValues), newValues: deepClone(newValues) });
}

function history(action, comment = '') { const user = Auth.currentUser(); return { id: uid('approval'), action, userId: user?.id || 'system', userName: user?.name || 'System', timestamp: new Date().toISOString(), comment }; }

export async function submitTransaction(id, comment = '') {
  if (!Auth.can('transactions', 'submit')) throw new Error('You do not have permission to submit vouchers.');
  const row = await DB.get('transactions', id); if (!row) throw new Error('Voucher not found.');
  if (!['Draft', 'Rejected'].includes(row.status)) throw new Error('Only draft or rejected vouchers can be submitted.');
  const valid = validateJournal(row.lines); if (!valid.valid) throw new Error(valid.errors.join(' '));
  const updated = { ...row, status: 'Submitted', approvalLevel: 1, approvalHistory: [...(row.approvalHistory || []), history('Submitted', comment || 'Submitted for approval.')] };
  await DB.put('transactions', updated); await audit('Submitted voucher', 'transactions', id, { status: row.status }, { status: updated.status });
  await Notifications.create({ type: 'approval', title: 'Voucher submitted', message: `${row.voucherNumber} is ready for review.`, module: 'transactions', recordId: id });
  return updated;
}

export async function approveTransaction(id, comment = '') {
  const row = await DB.get('transactions', id); if (!row) throw new Error('Voucher not found.');
  if (!Auth.canApproveTransaction(row)) throw new Error('You are not an independent authorised approver for this voucher.');
  if (!['Submitted', 'Under Review'].includes(row.status)) throw new Error('Only submitted vouchers can be approved.');
  const updated = { ...row, status: 'Approved', approvalLevel: Math.max(2, row.approvalLevel || 1), approvalHistory: [...(row.approvalHistory || []), history('Approved', comment || 'Approved for posting.')] };
  await DB.put('transactions', updated); await audit('Approved voucher', 'transactions', id, { status: row.status }, { status: updated.status });
  await Notifications.create({ type: 'approval', title: 'Voucher approved', message: `${row.voucherNumber} was approved.`, module: 'transactions', recordId: id, userId: row.enteredBy });
  return updated;
}

export async function rejectTransaction(id, reason = '') {
  const row = await DB.get('transactions', id); if (!row) throw new Error('Voucher not found.');
  if (!Auth.canApproveTransaction(row)) throw new Error('You do not have permission to reject this voucher.');
  if (!['Submitted', 'Under Review'].includes(row.status)) throw new Error('Only submitted vouchers can be rejected.');
  if (!reason.trim()) throw new Error('A rejection reason is required.');
  const updated = { ...row, status: 'Rejected', approvalLevel: 1, approvalHistory: [...(row.approvalHistory || []), history('Rejected', reason)] };
  await DB.put('transactions', updated); await audit('Rejected voucher', 'transactions', id, { status: row.status }, { status: updated.status, reason });
  await Notifications.create({ type: 'warning', title: 'Voucher rejected', message: `${row.voucherNumber}: ${reason}`, module: 'transactions', recordId: id, userId: row.enteredBy });
  return updated;
}

export async function postTransaction(id, comment = '') {
  if (!Auth.can('transactions', 'post')) throw new Error('You do not have permission to post vouchers.');
  const row = await DB.get('transactions', id); if (!row) throw new Error('Voucher not found.');
  if (row.status !== 'Approved') throw new Error('Only approved vouchers can be posted.');
  const valid = validateJournal(row.lines); if (!valid.valid) throw new Error(valid.errors.join(' '));
  const updated = { ...row, status: 'Posted', approvalLevel: 3, debit: valid.totalDebit, credit: valid.totalCredit, postedAt: new Date().toISOString(), approvalHistory: [...(row.approvalHistory || []), history('Posted', comment || 'Posted to the general ledger.')] };
  await DB.put('transactions', updated); await rebuildAccountBalances(); await audit('Posted voucher', 'transactions', id, { status: row.status }, { status: updated.status, debit: updated.debit, credit: updated.credit });
  await Notifications.create({ type: 'info', title: 'Voucher posted', message: `${row.voucherNumber} is now in the general ledger.`, module: 'transactions', recordId: id, userId: row.enteredBy });
  return updated;
}

export async function reverseTransaction(id, reason = '') {
  if (!Auth.can('transactions', 'reverse')) throw new Error('You do not have permission to reverse posted vouchers.');
  const row = await DB.get('transactions', id); if (!row || row.status !== 'Posted') throw new Error('Only posted vouchers can be reversed.');
  if (!reason.trim()) throw new Error('A reversal reason is required.');
  const reversalLines = (row.lines || []).map((line) => ({ ...line, id: uid('line'), debit: line.credit, credit: line.debit, baseDebit: lineBaseCredit(line), baseCredit: lineBaseDebit(line), description: `Reversal: ${line.description || row.description}` }));
  const reversal = { ...row, id: uid('txn'), serialNumber: `${row.voucherNumber}-R`, voucherNumber: `${row.voucherNumber}-R`, transactionType: 'Adjustment', status: 'Posted', description: `Reversal of ${row.voucherNumber}: ${reason}`, lines: reversalLines, debit: row.credit, credit: row.debit, approvalHistory: [history('Reversed', reason)], isReversal: true, reversedTransactionId: row.id, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString(), postedAt: new Date().toISOString() };
  await DB.put('transactions', { ...row, status: 'Reversed', reversedAt: new Date().toISOString(), reversalReason: reason }); await DB.add('transactions', reversal); await rebuildAccountBalances();
  await audit('Reversed posted voucher', 'transactions', id, { status: row.status }, { status: 'Reversed', reversalId: reversal.id });
  return reversal;
}

export async function createJournalTransaction(payload) {
  const user = Auth.currentUser();
  if (!user || !Auth.can('transactions', 'create')) throw new Error('You do not have permission to create vouchers.');
  const valid = validateJournal(payload.lines); if (!valid.valid) throw new Error(valid.errors.join(' '));
  const existing = await DB.getAll('transactions');
  const prefix = payload.typeCode || 'VCH';
  const sequence = existing.filter((row) => String(row.voucherNumber || '').startsWith(`${prefix}-`)).length + 1;
  const voucherNumber = payload.voucherNumber || `${prefix}-${String(sequence).padStart(4, '0')}`;
  if (existing.some((row) => row.voucherNumber === voucherNumber)) throw new Error('Voucher number already exists.');
  const date = payload.date || new Date().toISOString().slice(0, 10);
  const record = {
    id: uid('txn'), serialNumber: voucherNumber, date, voucherNumber, transactionType: payload.transactionType || 'Adjustment',
    costCenterId: payload.costCenterId || '', projectId: payload.projectId || '', individualName: payload.individualName || '', accountCode: payload.lines[0]?.accountCode || '', description: payload.description || '', invoiceNumber: payload.invoiceNumber || '',
    debit: valid.totalDebit, credit: valid.totalCredit, currency: payload.currency || 'PKR', exchangeRate: numeric(payload.exchangeRate || 1), paidTo: payload.paidTo || '', receivedFrom: payload.receivedFrom || '', enteredBy: user.id, enteredByName: user.name, notes: payload.notes || '', lines: payload.lines, attachments: payload.attachments || [], status: payload.status || 'Draft', approvalLevel: 0, approvalHistory: [], baseCurrency: 'PKR', isDemo: false, source: 'user-entry', createdAt: new Date().toISOString(), updatedAt: new Date().toISOString()
  };
  await DB.add('transactions', record); await audit('Created voucher', 'transactions', record.id, null, { voucherNumber, status: record.status, debit: record.debit, credit: record.credit });
  return record;
}

export async function saveDraftTransaction(id, payload) {
  const current = await DB.get('transactions', id); if (!current) throw new Error('Voucher not found.');
  if (current.status !== 'Draft' && current.status !== 'Rejected') throw new Error('Only drafts or rejected vouchers may be edited.');
  if (current.enteredBy !== Auth.currentUser()?.id && !Auth.can('transactions', 'editAll', { silent: true })) throw new Error('You may only edit your own draft vouchers.');
  const valid = validateJournal(payload.lines); if (!valid.valid) throw new Error(valid.errors.join(' '));
  const updated = { ...current, ...payload, debit: valid.totalDebit, credit: valid.totalCredit, status: 'Draft', updatedAt: new Date().toISOString() };
  await DB.put('transactions', updated); await audit('Edited voucher draft', 'transactions', id, current, updated); return updated;
}

export async function ledgerRows(filters = {}) {
  const [accounts, transactions] = await Promise.all([DB.getAll('accounts'), getPostedTransactions(filters)]);
  const map = new Map(accounts.map((row) => [row.code, row])); const rows = [];
  transactions.forEach((txn) => txn.lines?.forEach((line) => rows.push({ date: txn.date, voucherNumber: txn.voucherNumber, accountCode: line.accountCode, accountName: map.get(line.accountCode)?.name || line.accountName, description: line.description || txn.description, projectId: txn.projectId, costCenterId: txn.costCenterId, debit: lineBaseDebit(line), credit: lineBaseCredit(line), status: txn.status })));
  return rows.sort((a, b) => `${b.date}${b.voucherNumber}`.localeCompare(`${a.date}${a.voucherNumber}`));
}

export async function expenseByCategory(filters = {}) {
  const [accounts, transactions] = await Promise.all([DB.getAll('accounts'), getPostedTransactions(filters)]); const map = new Map(accounts.map((row) => [row.code, row])); const totals = new Map();
  transactions.forEach((txn) => txn.lines?.forEach((line) => { const account = map.get(line.accountCode); if (account?.type === 'Expense') totals.set(account.name, (totals.get(account.name) || 0) + lineBaseDebit(line) - lineBaseCredit(line)); }));
  return Array.from(totals, ([name, amount]) => ({ name, amount })).sort((a, b) => b.amount - a.amount);
}

export async function revenueByMonth(filters = {}) {
  const [accounts, transactions] = await Promise.all([DB.getAll('accounts'), getPostedTransactions(filters)]); const map = new Map(accounts.map((row) => [row.code, row])); const totals = new Map();
  transactions.forEach((txn) => txn.lines?.forEach((line) => { const account = map.get(line.accountCode); if (account?.type === 'Revenue') { const month = (txn.date || '').slice(0, 7); totals.set(month, (totals.get(month) || 0) + lineBaseCredit(line) - lineBaseDebit(line)); } }));
  return Array.from(totals, ([month, amount]) => ({ month, amount })).sort((a, b) => a.month.localeCompare(b.month));
}

export async function createAuditLog(action, module, recordId, previousValues = null, newValues = null) { return audit(action, module, recordId, previousValues, newValues); }
