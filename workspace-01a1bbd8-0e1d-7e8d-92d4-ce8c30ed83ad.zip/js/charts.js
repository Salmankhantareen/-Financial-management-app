import { formatNumber } from './accounting.js';

const instances = new Map();
const colors = { blue: '#2c91ff', blueFill: 'rgba(44,145,255,.16)', green: '#18c993', greenFill: 'rgba(18,201,139,.16)', red: '#f04452', orange: '#f5a623', purple: '#8058f7', grid: 'rgba(164,190,232,.10)', text: '#8096b4' };

function getCanvas(canvasOrId) { return typeof canvasOrId === 'string' ? document.getElementById(canvasOrId) : canvasOrId; }
function destroy(key) { if (instances.has(key)) { instances.get(key).destroy(); instances.delete(key); } }
function commonOptions({ stacked = false, currency = false } = {}) { return { responsive: true, maintainAspectRatio: false, interaction: { intersect: false, mode: 'index' }, plugins: { legend: { display: false }, tooltip: { backgroundColor: '#0b2347', borderColor: 'rgba(164,190,232,.25)', borderWidth: 1, titleColor: '#fff', bodyColor: '#c9d8ec', padding: 11, displayColors: true, callbacks: currency ? { label: (context) => ` ${context.dataset.label || ''}: ${formatNumber(context.parsed.y ?? context.parsed, 0)} PKR` } : {} } }, scales: { x: { stacked, grid: { display: false }, border: { display: false }, ticks: { color: colors.text, font: { size: 10, family: 'DM Sans' } } }, y: { stacked, grid: { color: colors.grid }, border: { display: false }, ticks: { color: colors.text, font: { size: 10, family: 'DM Sans' }, callback: (value) => value >= 1000000 ? `${(value / 1000000).toFixed(1)}M` : value >= 1000 ? `${(value / 1000).toFixed(0)}K` : value } } } }; }

export function lineChart(canvasOrId, { labels = [], datasets = [], key = 'line', currency = true } = {}) {
  const canvas = getCanvas(canvasOrId); if (!canvas || !window.Chart) return null; destroy(key);
  const chart = new Chart(canvas, { type: 'line', data: { labels, datasets: datasets.map((dataset, index) => ({ fill: index === 0, tension: .38, borderWidth: 2, pointRadius: 2.5, pointHoverRadius: 4, borderColor: index === 0 ? colors.blue : colors.green, backgroundColor: index === 0 ? colors.blueFill : colors.greenFill, ...dataset })) }, options: commonOptions({ currency }) });
  instances.set(key, chart); return chart;
}

export function barChart(canvasOrId, { labels = [], datasets = [], key = 'bar', horizontal = false, currency = true, stacked = false } = {}) {
  const canvas = getCanvas(canvasOrId); if (!canvas || !window.Chart) return null; destroy(key);
  const chart = new Chart(canvas, { type: 'bar', data: { labels, datasets: datasets.map((dataset, index) => ({ borderRadius: 4, borderSkipped: false, maxBarThickness: 22, backgroundColor: [colors.blue, colors.green, colors.orange, colors.purple, colors.red][index % 5], ...dataset })) }, options: { ...commonOptions({ stacked, currency }), indexAxis: horizontal ? 'y' : 'x' } });
  instances.set(key, chart); return chart;
}

export function doughnutChart(canvasOrId, { labels = [], data = [], key = 'doughnut', palette = [colors.blue, colors.green, colors.orange, colors.purple, colors.red, '#36c5d4'] } = {}) {
  const canvas = getCanvas(canvasOrId); if (!canvas || !window.Chart) return null; destroy(key);
  const chart = new Chart(canvas, { type: 'doughnut', data: { labels, datasets: [{ data, backgroundColor: palette, borderColor: '#0b2347', borderWidth: 4, hoverOffset: 4 }] }, options: { responsive: true, maintainAspectRatio: false, cutout: '73%', plugins: { legend: { display: false }, tooltip: { backgroundColor: '#0b2347', borderColor: 'rgba(164,190,232,.25)', borderWidth: 1, titleColor: '#fff', bodyColor: '#c9d8ec', padding: 10 } } } });
  instances.set(key, chart); return chart;
}

export function destroyAll() { instances.forEach((chart) => chart.destroy()); instances.clear(); }
export const chartColors = colors;
