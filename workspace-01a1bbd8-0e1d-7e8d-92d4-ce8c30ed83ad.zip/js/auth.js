import { DB, uid } from './database.js';

const SESSION_KEY = 'hacfm_session';
const roles = {
  'Super Administrator': ['*'],
  'Administrator': ['*', '-system.delete'],
  'Finance Manager': ['dashboard.view', 'users.view', 'employees.view', 'suppliers.view', 'customers.view', 'projects.view', 'projects.create', 'projects.edit', 'costCenters.view', 'transactions.*', 'vouchers.*', 'accounts.*', 'ledger.view', 'journals.*', 'cashBank.*', 'currencies.*', 'assets.view', 'inventory.view', 'revenue.view', 'expenses.*', 'reports.*', 'payments.*', 'receivables.*', 'payables.*', 'budgets.*', 'approvals.*', 'audit.view', 'notifications.view', 'settings.view'],
  'Accountant': ['dashboard.view', 'projects.view', 'costCenters.view', 'transactions.*', 'vouchers.*', 'accounts.view', 'ledger.view', 'journals.*', 'cashBank.*', 'currencies.view', 'reports.*', 'payments.*', 'receivables.*', 'payables.*', 'expenses.*', 'budgets.view', 'approvals.view', 'notifications.view'],
  'Project Manager': ['dashboard.view', 'projects.view', 'projects.edit', 'costCenters.view', 'transactions.view', 'transactions.create', 'transactions.edit', 'transactions.submit', 'reports.view', 'reports.export', 'budgets.view', 'notifications.view'],
  'Site Manager': ['dashboard.view', 'projects.view', 'costCenters.view', 'transactions.view', 'transactions.create', 'transactions.edit', 'transactions.submit', 'expenses.view', 'reports.view', 'notifications.view'],
  'Procurement Officer': ['dashboard.view', 'suppliers.*', 'projects.view', 'costCenters.view', 'transactions.view', 'transactions.create', 'transactions.submit', 'inventory.*', 'expenses.view', 'payables.view', 'reports.view', 'notifications.view'],
  'Cashier': ['dashboard.view', 'transactions.view', 'transactions.create', 'transactions.submit', 'cashBank.*', 'payments.*', 'reports.view', 'notifications.view'],
  'Auditor': ['dashboard.view', 'projects.view', 'costCenters.view', 'transactions.view', 'accounts.view', 'ledger.view', 'reports.*', 'audit.view', 'notifications.view'],
  'Read-Only User': ['dashboard.view', 'projects.view', 'costCenters.view', 'transactions.view', 'accounts.view', 'reports.view', 'notifications.view'],
  'Project User': ['dashboard.view', 'projects.view', 'costCenters.view', 'transactions.view', 'transactions.create', 'transactions.edit', 'transactions.submit', 'reports.view', 'notifications.view']
};

function readSession() {
  try {
    const raw = localStorage.getItem(SESSION_KEY) || sessionStorage.getItem(SESSION_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch { return null; }
}

function saveSession(payload, remember) {
  const serialized = JSON.stringify(payload);
  sessionStorage.removeItem(SESSION_KEY); localStorage.removeItem(SESSION_KEY);
  (remember ? localStorage : sessionStorage).setItem(SESSION_KEY, serialized);
}

function hasWildcard(permissionList, target) {
  if (permissionList.includes('*')) return true;
  if (permissionList.includes(target)) return true;
  const [module] = target.split('.');
  if (permissionList.includes(`${module}.*`)) return true;
  return false;
}

export const Auth = {
  rolePermissions: roles,
  currentUser() { return readSession()?.user || null; },
  session() { return readSession(); },
  isAuthenticated() { const session = readSession(); return Boolean(session?.user?.id && session.expiresAt > Date.now()); },
  initials(name = '') { return name.split(/\s+/).filter(Boolean).slice(0, 2).map((part) => part[0]).join('').toUpperCase() || 'HA'; },
  hasPermission(userOrModule, moduleOrAction, maybeAction) {
    const user = typeof userOrModule === 'object' ? userOrModule : this.currentUser();
    const module = typeof userOrModule === 'object' ? moduleOrAction : userOrModule;
    const action = typeof userOrModule === 'object' ? maybeAction : moduleOrAction;
    if (!user) return false;
    const target = `${module}.${action}`;
    const base = roles[user.role] || [];
    if (base.includes(`-${target}`)) return false;
    if (hasWildcard(base, target)) return true;
    const custom = user.permissions || {};
    if (custom[target] === false) return false;
    if (custom[target] === true) return true;
    if (custom[`${module}.*`] === true) return true;
    return false;
  },
  can(module, action, options = {}) {
    const allowed = this.hasPermission(module, action);
    if (!allowed && !options.silent) window.dispatchEvent(new CustomEvent('hacfm:permission-denied', { detail: { module, action } }));
    return allowed;
  },
  canApproveTransaction(transaction) {
    const user = this.currentUser();
    if (!user || !this.can('transactions', 'approve', { silent: true })) return false;
    if (transaction?.enteredBy === user.id && !this.can('transactions', 'approveSelf', { silent: true })) return false;
    return true;
  },
  async login(identity, password, remember = false) {
    const users = await DB.getAll('users');
    const query = String(identity || '').trim().toLowerCase();
    const user = users.find((item) => (item.email || '').toLowerCase() === query || (item.username || '').toLowerCase() === query);
    if (!user || user.password !== password) throw new Error('The credentials do not match a registered account.');
    if (user.status !== 'Active') throw new Error('This account is not active. Contact an administrator.');
    const now = new Date().toISOString();
    const updated = { ...user, lastLogin: now };
    await DB.put('users', updated);
    const safeUser = { ...updated }; delete safeUser.password;
    saveSession({ user: safeUser, remember, loginAt: now, expiresAt: Date.now() + (remember ? 30 : 1) * 86400000 }, remember);
    await DB.add('auditLogs', { id: uid('audit'), userId: user.id, userName: user.name, action: 'Signed in', module: 'authentication', recordId: user.id, timestamp: now, previousValues: { lastLogin: user.lastLogin || null }, newValues: { lastLogin: now }, isDemo: Boolean(user.isDemo) });
    return safeUser;
  },
  async logout({ redirect = true } = {}) {
    const user = this.currentUser();
    if (user) await DB.add('auditLogs', { id: uid('audit'), userId: user.id, userName: user.name, action: 'Signed out', module: 'authentication', recordId: user.id, timestamp: new Date().toISOString(), previousValues: null, newValues: null });
    localStorage.removeItem(SESSION_KEY); sessionStorage.removeItem(SESSION_KEY);
    if (redirect) window.location.href = 'login.html';
  },
  requireAuth(expectedWorkspace = '') {
    const session = readSession();
    if (!session || !session.user || session.expiresAt <= Date.now()) {
      localStorage.removeItem(SESSION_KEY); sessionStorage.removeItem(SESSION_KEY);
      window.location.replace('login.html'); return null;
    }
    if (expectedWorkspace === 'user' && session.user.role === 'Super Administrator') {
      window.location.replace('admin.html'); return null;
    }
    if (expectedWorkspace === 'admin' && session.user.role === 'Project User') {
      window.location.replace('user.html'); return null;
    }
    return session.user;
  },
  async changePassword(currentPassword, nextPassword) {
    const user = this.currentUser();
    if (!user) throw new Error('You must be signed in.');
    const stored = await DB.get('users', user.id);
    if (stored.password !== currentPassword) throw new Error('Current password is incorrect.');
    if (!nextPassword || nextPassword.length < 8) throw new Error('New password must contain at least 8 characters.');
    await DB.put('users', { ...stored, password: nextPassword });
    return true;
  }
};

export function roleOptions() { return Object.keys(roles); }
export function permissionMatrix() { return roles; }
