/*
 * IndexedDB data layer
 *
 * The application uses this module as a replaceable repository boundary. The
 * records are deliberately plain objects so the same service methods can later
 * call a REST API without changing page modules.
 */
const DB_NAME = 'hilal_amin_financial_system';
const DB_VERSION = 4;

export const STORES = [
  'settings', 'users', 'employees', 'suppliers', 'customers', 'projects',
  'costCenters', 'accounts', 'transactions', 'budgets', 'notifications',
  'auditLogs', 'exchangeRates', 'payments', 'assets', 'procurements'
];

const STORE_KEYS = {
  settings: 'id', users: 'id', employees: 'id', suppliers: 'id', customers: 'id',
  projects: 'id', costCenters: 'id', accounts: 'id', transactions: 'id', budgets: 'id',
  notifications: 'id', auditLogs: 'id', exchangeRates: 'id', payments: 'id', assets: 'id',
  procurements: 'id'
};

export const uid = (prefix = 'id') => `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 9)}`;
export const isoDate = (date = new Date()) => new Date(date).toISOString().slice(0, 10);
export const daysAgo = (days) => isoDate(Date.now() - days * 86400000);
export const deepClone = (value) => JSON.parse(JSON.stringify(value));

function requestToPromise(request) {
  return new Promise((resolve, reject) => {
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error || new Error('IndexedDB request failed'));
  });
}

function transactionToPromise(tx) {
  return new Promise((resolve, reject) => {
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error || new Error('IndexedDB transaction failed'));
    tx.onabort = () => reject(tx.error || new Error('IndexedDB transaction aborted'));
  });
}

export const DB = {
  _db: null,

  async init() {
    if (this._db) return this._db;
    if (!('indexedDB' in window)) throw new Error('IndexedDB is not available in this browser.');
    this._db = await new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, DB_VERSION);
      request.onupgradeneeded = (event) => {
        const db = event.target.result;
        STORES.forEach((store) => {
          if (!db.objectStoreNames.contains(store)) {
            const objectStore = db.createObjectStore(store, { keyPath: STORE_KEYS[store] || 'id' });
            objectStore.createIndex('updatedAt', 'updatedAt', { unique: false });
          }
        });
      };
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error || new Error('Could not open local database'));
    });
    this._db.onversionchange = () => this._db.close();
    await this.seedIfEmpty();
    return this._db;
  },

  async getAll(store) {
    const db = await this.init();
    return requestToPromise(db.transaction(store, 'readonly').objectStore(store).getAll());
  },

  async get(store, id) {
    const db = await this.init();
    return requestToPromise(db.transaction(store, 'readonly').objectStore(store).get(id));
  },

  async count(store) {
    const db = await this.init();
    return requestToPromise(db.transaction(store, 'readonly').objectStore(store).count());
  },

  async put(store, value) {
    const db = await this.init();
    const record = { ...value, updatedAt: new Date().toISOString() };
    await requestToPromise(db.transaction(store, 'readwrite').objectStore(store).put(record));
    return record;
  },

  async add(store, value) {
    const db = await this.init();
    const record = { ...value, id: value.id || uid(store.slice(0, 3)), createdAt: value.createdAt || new Date().toISOString(), updatedAt: new Date().toISOString() };
    await requestToPromise(db.transaction(store, 'readwrite').objectStore(store).add(record));
    return record;
  },

  async delete(store, id) {
    const db = await this.init();
    await requestToPromise(db.transaction(store, 'readwrite').objectStore(store).delete(id));
    return true;
  },

  async clear(store) {
    const db = await this.init();
    await requestToPromise(db.transaction(store, 'readwrite').objectStore(store).clear());
  },

  async bulkPut(store, records) {
    if (!records?.length) return [];
    const db = await this.init();
    const tx = db.transaction(store, 'readwrite');
    const objectStore = tx.objectStore(store);
    const stamped = records.map((record) => ({ ...record, updatedAt: record.updatedAt || new Date().toISOString() }));
    stamped.forEach((record) => objectStore.put(record));
    await transactionToPromise(tx);
    return stamped;
  },

  async bulkAdd(store, records) {
    if (!records?.length) return [];
    const db = await this.init();
    const tx = db.transaction(store, 'readwrite');
    const objectStore = tx.objectStore(store);
    const stamped = records.map((record) => ({ ...record, id: record.id || uid(store.slice(0, 3)), createdAt: record.createdAt || new Date().toISOString(), updatedAt: new Date().toISOString() }));
    stamped.forEach((record) => objectStore.add(record));
    await transactionToPromise(tx);
    return stamped;
  },

  async replaceStore(store, records) {
    await this.clear(store);
    return this.bulkPut(store, records || []);
  },

  async exportData() {
    await this.init();
    const data = {};
    for (const store of STORES) data[store] = await this.getAll(store);
    return { schema: 'hacfm-local-v1', exportedAt: new Date().toISOString(), stores: data };
  },

  async importData(payload, { replace = true } = {}) {
    if (!payload || payload.schema !== 'hacfm-local-v1' || !payload.stores) throw new Error('Invalid backup. Expected a HACFM local backup file.');
    await this.init();
    for (const store of STORES) {
      if (!Array.isArray(payload.stores[store])) continue;
      if (replace) await this.clear(store);
      await this.bulkPut(store, payload.stores[store]);
    }
    localStorage.setItem('hacfm_seeded_v4', 'true');
    return true;
  },

  async resetDemo() {
    await this.init();
    for (const store of STORES) await this.clear(store);
    await seedAll();
    localStorage.setItem('hacfm_seeded_v4', 'true');
    return true;
  },

  async seedIfEmpty() {
    const count = await requestToPromise(this._db.transaction('users', 'readonly').objectStore('users').count());
    if (count > 0) return;
    await seedAll();
    localStorage.setItem('hacfm_seeded_v4', 'true');
  }
};

const account = (code, name, type, parentCode = null, category = type, cashflowCategory = 'Not Applicable', flowCategory = 'Non-cash', extra = {}) => ({
  id: `acct-${code}`, code, name, type, parentCode, category, cashflowCategory, flowCategory,
  openingBalance: 0, debitBalance: 0, creditBalance: 0, currentBalance: 0, currency: 'PKR', status: 'Active',
  isGroup: false, source: 'demo-import', sourceNote: 'Demonstration row; replace with source PDF classification when supplied.', createdAt: '2026-01-01T00:00:00.000Z', ...extra
});

function makeDemoChart() {
  const rows = [];
  const usedCodes = new Set();
  const add = (row) => { if (!usedCodes.has(row.code)) { rows.push(row); usedCodes.add(row.code); } return row; };
  const roots = [
    ['1000', 'Assets', 'Asset', 'Assets', 'Not Applicable', 'Non-cash'],
    ['2000', 'Liabilities', 'Liability', 'Liabilities', 'Not Applicable', 'Non-cash'],
    ['3000', 'Equity', 'Equity', 'Equity', 'Not Applicable', 'Financing'],
    ['4000', 'Revenue', 'Revenue', 'Revenue', 'Operating Inflow', 'Operating'],
    ['5000', 'Expenses', 'Expense', 'Expenses', 'Operating Outflow', 'Operating'],
    ['9000', 'Suspense Account', 'Suspense', 'Suspense Account', 'Not Applicable', 'Non-cash']
  ];
  roots.forEach(([code, name, type, category, cash, flow]) => add(account(code, name, type, null, category, cash, flow, { isGroup: true })));

  const groups = [
    ['1010', 'Cash and Cash Equivalents', 'Asset', '1000', 'Operating Inflow', 'Operating'],
    ['1100', 'Receivables', 'Asset', '1000', 'Operating Inflow', 'Operating'],
    ['1200', 'Inventory and Materials', 'Asset', '1000', 'Operating Outflow', 'Operating'],
    ['1300', 'Prepayments and Advances', 'Asset', '1000', 'Operating Outflow', 'Operating'],
    ['1400', 'Investments', 'Asset', '1000', 'Investing', 'Investing'],
    ['1500', 'Property, Plant and Equipment', 'Asset', '1000', 'Investing', 'Investing'],
    ['1600', 'Accumulated Depreciation', 'Asset', '1000', 'Non-cash', 'Non-cash'],
    ['2010', 'Trade and Supplier Payables', 'Liability', '2000', 'Operating Outflow', 'Operating'],
    ['2100', 'Payroll and Employee Payables', 'Liability', '2000', 'Operating Outflow', 'Operating'],
    ['2200', 'Customer Advances', 'Liability', '2000', 'Operating Inflow', 'Operating'],
    ['2300', 'Taxes and Statutory Payables', 'Liability', '2000', 'Operating Outflow', 'Operating'],
    ['2400', 'Loans and Finance Liabilities', 'Liability', '2000', 'Financing', 'Financing'],
    ['3010', 'Share Capital and Contributions', 'Equity', '3000', 'Financing', 'Financing'],
    ['3100', 'Retained Earnings', 'Equity', '3000', 'Financing', 'Financing'],
    ['3200', 'Current Year Earnings', 'Equity', '3000', 'Financing', 'Financing'],
    ['4010', 'Construction Contract Revenue', 'Revenue', '4000', 'Operating Inflow', 'Operating'],
    ['4100', 'Other Operating Revenue', 'Revenue', '4000', 'Operating Inflow', 'Operating'],
    ['4200', 'Finance and Exchange Gains', 'Revenue', '4000', 'Operating Inflow', 'Operating'],
    ['5010', 'Direct Project Costs', 'Expense', '5000', 'Operating Outflow', 'Operating'],
    ['5100', 'Indirect / Administrative Costs', 'Expense', '5000', 'Operating Outflow', 'Operating'],
    ['5200', 'Payroll and People Costs', 'Expense', '5000', 'Operating Outflow', 'Operating'],
    ['5300', 'Depreciation and Amortisation', 'Expense', '5000', 'Non-cash', 'Non-cash'],
    ['5400', 'Finance and Exchange Costs', 'Expense', '5000', 'Operating Outflow', 'Operating'],
    ['5500', 'Other Expenses', 'Expense', '5000', 'Operating Outflow', 'Operating'],
    ['9010', 'Unallocated / Review', 'Suspense', '9000', 'Not Applicable', 'Non-cash']
  ];
  groups.forEach(([code, name, type, parent, cash, flow]) => add(account(code, name, type, parent, type === 'Asset' ? 'Assets' : `${type}s`, cash, flow, { isGroup: true })));

  const key = [
    ['1011', 'Cash on Hand - Mumtaz Sarafi', 'Asset', '1010'], ['1012', 'Cash on Hand - Project Sites', 'Asset', '1010'], ['1013', 'Petty Cash', 'Asset', '1010'], ['1014', 'Bank - Operating Account', 'Asset', '1010'], ['1015', 'Bank - Project Account', 'Asset', '1010'], ['1016', 'Currency Clearing Account (USD to AFA)', 'Asset', '1010'], ['1017', 'Currency Clearing Account (AFA to USD)', 'Asset', '1010'],
    ['1110', 'Trade Receivables - Construction Clients', 'Asset', '1100'], ['1120', 'Retention Receivable', 'Asset', '1100'], ['1130', 'Employee Advances', 'Asset', '1100'], ['1140', 'Supplier Advances', 'Asset', '1100'],
    ['1210', 'Construction Materials Inventory', 'Asset', '1200'], ['1220', 'Fuel Inventory', 'Asset', '1200'], ['1230', 'Spare Parts Inventory', 'Asset', '1200'],
    ['1310', 'Prepaid Insurance', 'Asset', '1300'], ['1320', 'Prepaid Rent', 'Asset', '1300'],
    ['1510', 'Land', 'Asset', '1500'], ['1520', 'Buildings', 'Asset', '1500'], ['1530', 'Vehicles', 'Asset', '1500'], ['1540', 'Construction Machinery', 'Asset', '1500'], ['1550', 'Heavy Equipment', 'Asset', '1500'], ['1560', 'Office Furniture', 'Asset', '1500'], ['1570', 'Computers and IT Equipment', 'Asset', '1500'], ['1580', 'Tools and Small Equipment', 'Asset', '1500'],
    ['1610', 'Accumulated Depreciation - Vehicles', 'Asset', '1600'], ['1620', 'Accumulated Depreciation - Machinery', 'Asset', '1600'], ['1630', 'Accumulated Depreciation - Office Assets', 'Asset', '1600'],
    ['2011', 'Supplier Payables - Materials', 'Liability', '2010'], ['2012', 'Supplier Payables - Services', 'Liability', '2010'], ['2013', 'Subcontractor Payables', 'Liability', '2010'], ['2014', 'Accrued Expenses', 'Liability', '2010'],
    ['2110', 'Salary Payable', 'Liability', '2100'], ['2120', 'Employee Benefits Payable', 'Liability', '2100'], ['2130', 'Employee Advance Clearing', 'Liability', '2100'],
    ['2210', 'Customer Deposits', 'Liability', '2200'], ['2310', 'Withholding Tax Payable', 'Liability', '2300'], ['2320', 'Sales Tax Payable', 'Liability', '2300'], ['2410', 'Bank Loan - Operating', 'Liability', '2400'],
    ['3011', 'Owner Capital', 'Equity', '3010'], ['3012', 'Capital Contributions', 'Equity', '3010'], ['3110', 'Prior Year Retained Earnings', 'Equity', '3100'], ['3210', 'Current Year Profit / Loss', 'Equity', '3200'],
    ['4011', 'Asphalt Works Revenue', 'Revenue', '4010'], ['4012', 'Road Construction Revenue', 'Revenue', '4010'], ['4013', 'Project Variation Revenue', 'Revenue', '4010'], ['4110', 'Equipment Hire Revenue', 'Revenue', '4100'], ['4120', 'Other Service Revenue', 'Revenue', '4100'], ['4210', 'Foreign Exchange Gain', 'Revenue', '4200'],
    ['5011', 'Materials', 'Expense', '5010'], ['5012', 'Diesel', 'Expense', '5010'], ['5013', 'Black Fuel', 'Expense', '5010'], ['5014', 'Direct Labor', 'Expense', '5010'], ['5015', 'Equipment Rental', 'Expense', '5010'], ['5016', 'Equipment Fuel', 'Expense', '5010'], ['5017', 'Equipment Repairs', 'Expense', '5010'], ['5018', 'Subcontractors', 'Expense', '5010'], ['5019', 'Transportation', 'Expense', '5010'], ['5020', 'Site Costs', 'Expense', '5010'], ['5021', 'Project Services', 'Expense', '5010'], ['5022', 'Leased Machinery', 'Expense', '5010'], ['5023', 'Project Permits', 'Expense', '5010'],
    ['5110', 'Office Utilities', 'Expense', '5100'], ['5111', 'Office Supplies', 'Expense', '5100'], ['5112', 'IT Expenses', 'Expense', '5100'], ['5113', 'Office Rent', 'Expense', '5100'], ['5114', 'Administrative Salaries', 'Expense', '5100'], ['5115', 'Travel', 'Expense', '5100'], ['5116', 'Accommodation', 'Expense', '5100'], ['5117', 'Insurance', 'Expense', '5100'], ['5118', 'Advertising', 'Expense', '5100'], ['5119', 'Staff Training', 'Expense', '5100'],
    ['5210', 'Monthly Salaries', 'Expense', '5200'], ['5211', 'Allowances', 'Expense', '5200'], ['5212', 'Bonuses', 'Expense', '5200'], ['5213', 'Payroll Deductions', 'Expense', '5200'],
    ['5310', 'Depreciation Expense', 'Expense', '5300'], ['5410', 'Bank Charges', 'Expense', '5400'], ['5411', 'Finance Costs', 'Expense', '5400'], ['5412', 'Foreign Exchange Loss', 'Expense', '5400'], ['5510', 'Other Expenses', 'Expense', '5500']
  ];
  const flows = { Asset: ['Operating Inflow', 'Operating Outflow'], Liability: ['Operating Outflow'], Equity: ['Financing'], Revenue: ['Operating Inflow'], Expense: ['Operating Outflow'], Suspense: ['Not Applicable'] };
  key.forEach(([code, name, type, parent]) => add(account(code, name, type, parent, `${type}s`, flows[type]?.[0] || 'Not Applicable', type === 'Asset' && parent === '1500' ? 'Investing' : type === 'Equity' ? 'Financing' : type === 'Revenue' ? 'Operating' : type === 'Suspense' ? 'Non-cash' : 'Operating')));

  const targets = { Asset: 57, Liability: 38, Equity: 19, Revenue: 29, Expense: 90, Suspense: 3 };
  const names = {
    Asset: ['Project Retention Receivable', 'Advance to Site Vendor', 'Prepaid Contract Cost', 'Plant Spares', 'Workshop Inventory', 'Site Equipment Deposit', 'Long-term Deposit'],
    Liability: ['Accrued Site Services', 'Contractor Retention Payable', 'Employee Tax Payable', 'Deferred Revenue', 'Equipment Lease Payable', 'Other Current Liability'],
    Equity: ['Reserve - Project Contingency', 'Capital Reserve', 'Partner Current Account', 'Opening Equity Adjustment'],
    Revenue: ['Bitumen Supply Revenue', 'Plant Hire Revenue', 'Consulting Revenue', 'Miscellaneous Revenue'],
    Expense: ['Site Security', 'Laboratory Testing', 'Surveying', 'Mobilisation', 'Demobilisation', 'Small Tools', 'Telephone and Internet', 'Vehicle Running Costs', 'Legal and Professional Fees', 'Bank Service Charges'],
    Suspense: ['Pending Allocation', 'Imported Opening Difference']
  };
  const parentPool = { Asset: ['1100', '1200', '1300', '1500'], Liability: ['2010', '2100', '2300', '2400'], Equity: ['3010', '3100', '3200'], Revenue: ['4010', '4100', '4200'], Expense: ['5010', '5100', '5200', '5400', '5500'], Suspense: ['9010'] };
  Object.entries(targets).forEach(([type, target]) => {
    let index = 1;
    while (rows.filter((row) => row.type === type).length < target) {
      const parent = parentPool[type][(index - 1) % parentPool[type].length];
      const code = `${type === 'Asset' ? 17 : type === 'Liability' ? 25 : type === 'Equity' ? 33 : type === 'Revenue' ? 43 : type === 'Expense' ? 56 : 92}${String(index).padStart(2, '0')}`;
      if (usedCodes.has(code)) { index += 1; continue; }
      const collection = names[type];
      const name = `${collection[(index - 1) % collection.length]} ${Math.ceil(index / collection.length) > 1 ? `(${Math.ceil(index / collection.length)})` : ''}`.trim();
      const cash = type === 'Revenue' ? 'Operating Inflow' : type === 'Expense' ? 'Operating Outflow' : type === 'Equity' ? 'Financing' : type === 'Suspense' ? 'Not Applicable' : 'Operating Outflow';
      const flow = type === 'Asset' && ['1500', '1400'].includes(parent) ? 'Investing' : type === 'Equity' ? 'Financing' : type === 'Suspense' ? 'Non-cash' : 'Operating';
      add(account(code, name, type, parent, `${type}s`, cash, flow));
      index += 1;
    }
  });
  // The source brief specifies 236 populated rows. Keep a deterministic count in this prototype.
  return rows.slice(0, 236);
}

const accountCode = (accounts, code) => accounts.find((item) => item.code === code) || accounts[0];
const line = (accounts, code, { debit = 0, credit = 0, currency = 'PKR', exchangeRate = 1, projectId = 'prj-001', costCenterId = 'cc-site-01', description = '' } = {}) => {
  const item = accountCode(accounts, code);
  const amount = debit || credit;
  return {
    id: uid('line'), accountId: item.id, accountCode: item.code, accountName: item.name,
    projectId, costCenterId, description, debit, credit, currency, exchangeRate,
    baseDebit: Math.round(debit * exchangeRate * 100) / 100, baseCredit: Math.round(credit * exchangeRate * 100) / 100,
    originalAmount: amount
  };
};

function transaction(accounts, data) {
  const baseDebit = data.lines.reduce((sum, item) => sum + Number(item.baseDebit || 0), 0);
  const baseCredit = data.lines.reduce((sum, item) => sum + Number(item.baseCredit || 0), 0);
  return {
    id: data.id || uid('txn'), serialNumber: data.serialNumber || data.voucherNumber, date: data.date, voucherNumber: data.voucherNumber,
    transactionType: data.transactionType, costCenterId: data.costCenterId || 'cc-site-01', projectId: data.projectId || 'prj-001',
    individualName: data.individualName || '', accountCode: data.lines[0]?.accountCode || '', description: data.description,
    invoiceNumber: data.invoiceNumber || '', debit: baseDebit, credit: baseCredit, currency: data.currency || 'PKR', exchangeRate: data.exchangeRate || 1,
    paidTo: data.paidTo || '', receivedFrom: data.receivedFrom || '', enteredBy: data.enteredBy || 'usr-admin', enteredByName: data.enteredByName || 'System Administrator',
    notes: data.notes || '', lines: data.lines, attachments: data.attachments || [], status: data.status || 'Posted', approvalLevel: data.approvalLevel || (data.status === 'Posted' ? 3 : 0),
    approvalHistory: data.approvalHistory || [], baseCurrency: 'PKR', isDemo: true, source: 'demo-data', createdAt: `${data.date}T10:00:00.000Z`, updatedAt: `${data.date}T10:00:00.000Z`, postedAt: data.status === 'Posted' ? `${data.date}T12:00:00.000Z` : null
  };
}

async function seedAll() {
  const accounts = makeDemoChart();
  const users = [
    { id: 'usr-admin', username: 'admin', email: 'admin@hilalamin.com', password: 'Admin@123', name: 'Mumtaz Rahimi', role: 'Super Administrator', department: 'Executive Office', status: 'Active', assignedProjects: ['prj-001'], assignedCostCenters: ['cc-ho-01', 'cc-plant-01', 'cc-site-01', 'cc-site-02'], permissions: {}, lastLogin: null, isDemo: true },
    { id: 'usr-finance', username: 'finance', email: 'finance@hilalamin.com', password: 'Finance@123', name: 'Samira Ahmadi', role: 'Finance Manager', department: 'Finance & Accounts', status: 'Active', assignedProjects: ['prj-001'], assignedCostCenters: ['cc-ho-01', 'cc-plant-01', 'cc-site-01'], permissions: { 'users.view': true, 'transactions.view': true, 'transactions.create': true, 'transactions.edit': true, 'transactions.submit': true, 'transactions.approve': true, 'transactions.post': true, 'reports.view': true, 'reports.export': true, 'accounts.view': true, 'projects.view': true, 'projects.edit': true, 'budgets.view': true, 'budgets.edit': true }, lastLogin: null, isDemo: true },
    { id: 'usr-user', username: 'siteuser', email: 'user@hilalamin.com', password: 'User@123', name: 'Omar Safi', role: 'Project User', department: 'Project Delivery', status: 'Active', assignedProjects: ['prj-001'], assignedCostCenters: ['cc-site-01'], permissions: { 'dashboard.view': true, 'transactions.view': true, 'transactions.create': true, 'transactions.edit': true, 'transactions.submit': true, 'projects.view': true, 'reports.view': true, 'reports.export': false }, lastLogin: null, isDemo: true }
  ];
  const projects = [
    { id: 'prj-001', code: 'PRJ-001', name: 'Boldak District Asphalt Project', client: 'Municipal Infrastructure Authority (Demo)', contractValue: 128000000, budget: 96500000, startDate: '2026-01-05', endDate: '2026-11-30', managerId: 'usr-admin', managerName: 'Mumtaz Rahimi', status: 'Active', notes: 'Demonstration project seeded to show project accounting and budget control.', isDemo: true },
    { id: 'prj-002', code: 'PRJ-002', name: 'North Ring Road Rehabilitation', client: 'Regional Roads Directorate (Demo)', contractValue: 78500000, budget: 61200000, startDate: '2026-03-01', endDate: '2026-12-15', managerId: 'usr-finance', managerName: 'Samira Ahmadi', status: 'Planning', notes: 'Demo planning project.', isDemo: true }
  ];
  const costCenters = [
    { id: 'cc-ho-01', code: 'HO-01', name: 'Head Office', type: 'Administrative', projectId: '', manager: 'Samira Ahmadi', status: 'Active', isDemo: true },
    { id: 'cc-plant-01', code: 'WH-01', name: 'Asphalt Plant', type: 'Plant / Warehouse', projectId: 'prj-001', manager: 'Nadir Khan', status: 'Active', isDemo: true },
    { id: 'cc-site-01', code: 'SITE-01', name: 'Project Site 1', type: 'Project Site', projectId: 'prj-001', manager: 'Omar Safi', status: 'Active', isDemo: true },
    { id: 'cc-site-02', code: 'SITE-02', name: 'Project Site 2', type: 'Project Site', projectId: 'prj-002', manager: 'Farid Noor', status: 'Active', isDemo: true }
  ];
  const employees = [
    { id: 'emp-001', employeeId: 'EMP-001', name: 'Mumtaz Rahimi', email: 'mumtaz@hilalamin.com', phone: '+92 300 000 001', department: 'Executive Office', position: 'Managing Director', joiningDate: '2018-02-01', salary: 475000, projectId: '', costCenterId: 'cc-ho-01', status: 'Active', isDemo: true },
    { id: 'emp-002', employeeId: 'EMP-002', name: 'Samira Ahmadi', email: 'samira@hilalamin.com', phone: '+92 300 000 002', department: 'Finance & Accounts', position: 'Finance Manager', joiningDate: '2020-08-16', salary: 285000, projectId: 'prj-001', costCenterId: 'cc-ho-01', status: 'Active', isDemo: true },
    { id: 'emp-003', employeeId: 'EMP-003', name: 'Omar Safi', email: 'omar@hilalamin.com', phone: '+92 300 000 003', department: 'Project Delivery', position: 'Site Manager', joiningDate: '2022-04-10', salary: 190000, projectId: 'prj-001', costCenterId: 'cc-site-01', status: 'Active', isDemo: true },
    { id: 'emp-004', employeeId: 'EMP-004', name: 'Nadir Khan', email: 'nadir@hilalamin.com', phone: '+92 300 000 004', department: 'Plant Operations', position: 'Plant Supervisor', joiningDate: '2021-11-03', salary: 155000, projectId: 'prj-001', costCenterId: 'cc-plant-01', status: 'Active', isDemo: true }
  ];
  const suppliers = [
    { id: 'sup-001', supplierId: 'SUP-001', name: 'Kabul Bitumen & Materials (Demo)', contact: '+93 700 100 001', email: 'accounts@kabulmaterials.demo', address: 'Industrial Zone, Kabul', taxInfo: 'TIN-DEMO-001', openingBalance: 250000, totalPurchases: 1480000, totalPayments: 900000, outstanding: 830000, status: 'Active', isDemo: true },
    { id: 'sup-002', supplierId: 'SUP-002', name: 'Ariana Heavy Equipment Rental (Demo)', contact: '+93 700 100 002', email: 'billing@arianaequipment.demo', address: 'West Works Yard', taxInfo: 'TIN-DEMO-002', openingBalance: 0, totalPurchases: 650000, totalPayments: 0, outstanding: 650000, status: 'Active', isDemo: true },
    { id: 'sup-003', supplierId: 'SUP-003', name: 'Mumtaz Fuel Trading (Demo)', contact: '+93 700 100 003', email: 'sales@mumtazfuel.demo', address: 'Karte Naw', taxInfo: 'TIN-DEMO-003', openingBalance: 0, totalPurchases: 245000, totalPayments: 245000, outstanding: 0, status: 'Active', isDemo: true }
  ];
  const customers = [
    { id: 'cus-001', customerId: 'CUS-001', name: 'Municipal Infrastructure Authority (Demo)', contact: '+92 21 000 0100', email: 'projects@mia.demo', address: 'Civic Centre', contractDetails: 'Boldak District Asphalt Project', openingBalance: 0, totalRevenue: 3500000, totalReceivables: 3500000, receivedPayments: 0, outstanding: 3500000, status: 'Active', isDemo: true },
    { id: 'cus-002', customerId: 'CUS-002', name: 'Regional Roads Directorate (Demo)', contact: '+92 21 000 0200', email: 'contracts@rrd.demo', address: 'Roads House', contractDetails: 'North Ring Road Rehabilitation', openingBalance: 0, totalRevenue: 0, totalReceivables: 0, receivedPayments: 0, outstanding: 0, status: 'Active', isDemo: true }
  ];
  const exchangeRates = [
    { id: 'rate-pkr', currency: 'PKR', baseCurrency: 'PKR', rate: 1, effectiveDate: '2026-01-01', source: 'System base currency', isDemo: true },
    { id: 'rate-usd', currency: 'USD', baseCurrency: 'PKR', rate: 279, effectiveDate: '2026-02-01', source: 'Demonstration rate', isDemo: true },
    { id: 'rate-afa', currency: 'AFA', baseCurrency: 'PKR', rate: 3.9, effectiveDate: '2026-02-01', source: 'Demonstration rate', isDemo: true }
  ];
  const transactions = [
    transaction(accounts, { id: 'txn-000', date: daysAgo(365), voucherNumber: 'ADJ-0000', transactionType: 'Adjustment', projectId: '', costCenterId: 'cc-ho-01', description: 'Demonstration opening balance posted to operating bank', lines: [line(accounts, '1014', { debit: 15000000, projectId: '', costCenterId: 'cc-ho-01', description: 'Opening bank balance' }), line(accounts, '3011', { credit: 15000000, projectId: '', costCenterId: 'cc-ho-01', description: 'Opening owner capital' })] }),
    transaction(accounts, { id: 'txn-001', date: daysAgo(260), voucherNumber: 'CP-0001', transactionType: 'Cash Payment', projectId: 'prj-001', costCenterId: 'cc-site-01', description: 'Diesel issued for asphalt crew and site vehicles', paidTo: 'Mumtaz Fuel Trading (Demo)', lines: [line(accounts, '5012', { debit: 245000, projectId: 'prj-001', costCenterId: 'cc-site-01', description: 'Diesel expense' }), line(accounts, '1012', { credit: 245000, projectId: 'prj-001', costCenterId: 'cc-site-01', description: 'Cash payment' })] }),
    transaction(accounts, { id: 'txn-002', date: daysAgo(245), voucherNumber: 'PR-0002', transactionType: 'Purchase', projectId: 'prj-001', costCenterId: 'cc-plant-01', description: 'Bitumen and aggregate materials received', invoiceNumber: 'INV-DEMO-842', paidTo: 'Kabul Bitumen & Materials (Demo)', lines: [line(accounts, '5011', { debit: 1480000, projectId: 'prj-001', costCenterId: 'cc-plant-01', description: 'Materials purchase' }), line(accounts, '2011', { credit: 1480000, projectId: 'prj-001', costCenterId: 'cc-plant-01', description: 'Supplier payable' })] }),
    transaction(accounts, { id: 'txn-003', date: daysAgo(228), voucherNumber: 'CR-0003', transactionType: 'Cash Receive', projectId: 'prj-001', costCenterId: 'cc-ho-01', description: 'Certified progress revenue recognised', invoiceNumber: 'CERT-DEMO-01', receivedFrom: 'Municipal Infrastructure Authority (Demo)', lines: [line(accounts, '1110', { debit: 3500000, projectId: 'prj-001', costCenterId: 'cc-ho-01', description: 'Trade receivable' }), line(accounts, '4011', { credit: 3500000, projectId: 'prj-001', costCenterId: 'cc-ho-01', description: 'Asphalt works revenue' })] }),
    transaction(accounts, { id: 'txn-004', date: daysAgo(185), voucherNumber: 'BP-0004', transactionType: 'Bill Payment', projectId: 'prj-001', costCenterId: 'cc-ho-01', description: 'Part payment against material supplier invoice', invoiceNumber: 'INV-DEMO-842', paidTo: 'Kabul Bitumen & Materials (Demo)', lines: [line(accounts, '2011', { debit: 900000, projectId: 'prj-001', costCenterId: 'cc-ho-01', description: 'Supplier payable settlement' }), line(accounts, '1014', { credit: 900000, projectId: 'prj-001', costCenterId: 'cc-ho-01', description: 'Operating bank payment' })] }),
    transaction(accounts, { id: 'txn-005', date: daysAgo(151), voucherNumber: 'ADJ-0005', transactionType: 'Adjustment', projectId: 'prj-001', costCenterId: 'cc-site-01', description: 'Direct labor accrued for February site cycle', lines: [line(accounts, '5014', { debit: 415000, projectId: 'prj-001', costCenterId: 'cc-site-01', description: 'Direct labor' }), line(accounts, '2110', { credit: 415000, projectId: 'prj-001', costCenterId: 'cc-site-01', description: 'Salary payable' })] }),
    transaction(accounts, { id: 'txn-006', date: daysAgo(125), voucherNumber: 'CD-0006', transactionType: 'Cash Deposit', projectId: 'prj-001', costCenterId: 'cc-site-01', description: 'Deposit of site cash collection to project bank', lines: [line(accounts, '1015', { debit: 500000, projectId: 'prj-001', costCenterId: 'cc-site-01', description: 'Project bank deposit' }), line(accounts, '1012', { credit: 500000, projectId: 'prj-001', costCenterId: 'cc-site-01', description: 'Cash transferred' })] }),
    transaction(accounts, { id: 'txn-007', date: daysAgo(92), voucherNumber: 'EX-0007', transactionType: 'Currency Exchange', currency: 'USD', exchangeRate: 279, projectId: 'prj-001', costCenterId: 'cc-ho-01', description: 'USD clearing conversion recorded at historical rate', lines: [line(accounts, '1016', { debit: 1000, currency: 'USD', exchangeRate: 279, projectId: 'prj-001', costCenterId: 'cc-ho-01', description: 'USD clearing debit' }), line(accounts, '1014', { credit: 279000, currency: 'PKR', exchangeRate: 1, projectId: 'prj-001', costCenterId: 'cc-ho-01', description: 'Operating bank credit' })] }),
    transaction(accounts, { id: 'txn-008', date: daysAgo(10), voucherNumber: 'CP-0008', transactionType: 'Cash Payment', status: 'Submitted', approvalLevel: 1, projectId: 'prj-001', costCenterId: 'cc-site-01', description: 'Equipment rental for paving crew', paidTo: 'Ariana Heavy Equipment Rental (Demo)', notes: 'Awaiting Finance Manager review.', lines: [line(accounts, '5015', { debit: 325000, projectId: 'prj-001', costCenterId: 'cc-site-01', description: 'Equipment rental' }), line(accounts, '1012', { credit: 325000, projectId: 'prj-001', costCenterId: 'cc-site-01', description: 'Cash payment' })], approvalHistory: [{ id: uid('approval'), action: 'Submitted', userId: 'usr-user', userName: 'Omar Safi', timestamp: new Date(Date.now() - 9 * 86400000).toISOString(), comment: 'Submitted for project expense approval.' }] }),
    transaction(accounts, { id: 'txn-009', date: daysAgo(4), voucherNumber: 'PR-0009', transactionType: 'Purchase', status: 'Draft', approvalLevel: 0, projectId: 'prj-001', costCenterId: 'cc-plant-01', description: 'Aggregate delivery — draft', invoiceNumber: 'DRAFT-001', paidTo: 'Kabul Bitumen & Materials (Demo)', lines: [line(accounts, '5011', { debit: 420000, projectId: 'prj-001', costCenterId: 'cc-plant-01', description: 'Draft materials' }), line(accounts, '2011', { credit: 420000, projectId: 'prj-001', costCenterId: 'cc-plant-01', description: 'Draft payable' })] }),
    transaction(accounts, { id: 'txn-010', date: daysAgo(28), voucherNumber: 'CP-0010', transactionType: 'Cash Payment', status: 'Rejected', approvalLevel: 1, projectId: 'prj-001', costCenterId: 'cc-site-01', description: 'Site hospitality expense', notes: 'Rejected: supporting invoice required.', lines: [line(accounts, '5510', { debit: 78000, projectId: 'prj-001', costCenterId: 'cc-site-01', description: 'Other expense' }), line(accounts, '1012', { credit: 78000, projectId: 'prj-001', costCenterId: 'cc-site-01', description: 'Cash payment' })], approvalHistory: [{ id: uid('approval'), action: 'Rejected', userId: 'usr-finance', userName: 'Samira Ahmadi', timestamp: new Date(Date.now() - 27 * 86400000).toISOString(), comment: 'Please attach original invoice and resend.' }] })
  ];
  const budgets = [
    { id: 'bud-001', name: 'PRJ-001 Direct Cost Budget', fiscalYear: '2026', projectId: 'prj-001', costCenterId: '', accountCode: '5010', accountName: 'Direct Project Costs', amount: 62000000, monthlyLimit: 5200000, status: 'Approved', notes: 'Demonstration project budget.', isDemo: true },
    { id: 'bud-002', name: 'PRJ-001 Materials', fiscalYear: '2026', projectId: 'prj-001', costCenterId: 'cc-plant-01', accountCode: '5011', accountName: 'Materials', amount: 28500000, monthlyLimit: 2400000, status: 'Approved', notes: '', isDemo: true },
    { id: 'bud-003', name: 'PRJ-001 Site Fuel', fiscalYear: '2026', projectId: 'prj-001', costCenterId: 'cc-site-01', accountCode: '5012', accountName: 'Diesel', amount: 9200000, monthlyLimit: 850000, status: 'Approved', notes: '', isDemo: true },
    { id: 'bud-004', name: 'PRJ-002 Mobilisation', fiscalYear: '2026', projectId: 'prj-002', costCenterId: 'cc-site-02', accountCode: '5010', accountName: 'Direct Project Costs', amount: 18000000, monthlyLimit: 1600000, status: 'Draft', notes: '', isDemo: true }
  ];
  const payments = [
    { id: 'pay-001', paymentNumber: 'PAY-0001', date: daysAgo(185), entityType: 'Supplier', entityId: 'sup-001', entityName: 'Kabul Bitumen & Materials (Demo)', amount: 900000, currency: 'PKR', method: 'Bank Transfer', transactionId: 'txn-004', status: 'Posted', projectId: 'prj-001', isDemo: true },
    { id: 'pay-002', paymentNumber: 'PAY-0002', date: daysAgo(55), entityType: 'Customer', entityId: 'cus-001', entityName: 'Municipal Infrastructure Authority (Demo)', amount: 1250000, currency: 'PKR', method: 'Bank Transfer', transactionId: '', status: 'Pending', projectId: 'prj-001', isDemo: true }
  ];
  const assets = [
    { id: 'asset-001', assetCode: 'FA-001', name: 'Hino Site Truck', category: 'Vehicles', purchaseDate: '2025-04-15', purchaseCost: 8400000, location: 'Project Site 1', projectId: 'prj-001', method: 'Straight Line', usefulLife: 8, accumulatedDepreciation: 1050000, currentBookValue: 7350000, status: 'Active', isDemo: true },
    { id: 'asset-002', assetCode: 'FA-002', name: 'Asphalt Paver', category: 'Heavy Equipment', purchaseDate: '2024-09-01', purchaseCost: 28500000, location: 'Asphalt Plant', projectId: 'prj-001', method: 'Straight Line', usefulLife: 10, accumulatedDepreciation: 4275000, currentBookValue: 24225000, status: 'Active', isDemo: true }
  ];
  const procurements = [
    { id: 'proc-001', requestNumber: 'PRQ-0001', date: daysAgo(13), type: 'Purchase Request', description: 'Additional aggregate for site 1', supplierId: 'sup-001', supplierName: 'Kabul Bitumen & Materials (Demo)', projectId: 'prj-001', costCenterId: 'cc-plant-01', amount: 420000, status: 'Submitted', requestedBy: 'usr-user', isDemo: true },
    { id: 'proc-002', requestNumber: 'PO-0001', date: daysAgo(42), type: 'Purchase Order', description: 'Bitumen supply — February cycle', supplierId: 'sup-001', supplierName: 'Kabul Bitumen & Materials (Demo)', projectId: 'prj-001', costCenterId: 'cc-plant-01', amount: 1480000, status: 'Approved', requestedBy: 'usr-finance', isDemo: true }
  ];
  const notifications = [
    { id: 'notif-001', userId: 'usr-finance', type: 'approval', title: 'Voucher awaiting review', message: 'CP-0008 equipment rental is ready for your review.', module: 'transactions', recordId: 'txn-008', read: false, createdAt: new Date(Date.now() - 2 * 3600000).toISOString() },
    { id: 'notif-002', userId: 'usr-admin', type: 'budget', title: 'Budget attention required', message: 'PRJ-001 diesel budget is approaching its monthly limit.', module: 'budgets', recordId: 'bud-003', read: false, createdAt: new Date(Date.now() - 9 * 3600000).toISOString() },
    { id: 'notif-003', userId: 'usr-user', type: 'info', title: 'Submission received', message: 'Your voucher CP-0008 was submitted for review.', module: 'transactions', recordId: 'txn-008', read: true, createdAt: new Date(Date.now() - 9 * 86400000).toISOString() }
  ];
  const auditLogs = [
    { id: 'audit-001', userId: 'usr-admin', userName: 'Mumtaz Rahimi', action: 'Seeded demonstration data', module: 'system', recordId: 'seed-v4', timestamp: new Date().toISOString(), previousValues: null, newValues: { stores: STORES.length }, isDemo: true },
    { id: 'audit-002', userId: 'usr-user', userName: 'Omar Safi', action: 'Submitted voucher', module: 'transactions', recordId: 'txn-008', timestamp: new Date(Date.now() - 9 * 86400000).toISOString(), previousValues: { status: 'Draft' }, newValues: { status: 'Submitted' }, isDemo: true }
  ];
  const settings = [
    { id: 'company', companyName: 'Hilal Amin Construction Company', legalName: 'Hilal Amin Construction Company', tagline: 'Construction · Infrastructure · Delivery', phone: '+92 21 000 0000', email: 'finance@hilalamin.com', address: 'Karachi, Sindh, Pakistan', logoText: 'HA', financialYearStart: '2026-01-01', financialYearEnd: '2026-12-31', baseCurrency: 'PKR', dateFormat: 'DD MMM YYYY', numberFormat: 'en-PK', theme: 'dark', voucherPrefix: 'VCH', notificationEmail: false, demoMode: true }
  ];
  await DB.bulkPut('settings', settings);
  await DB.bulkPut('users', users); await DB.bulkPut('accounts', accounts); await DB.bulkPut('projects', projects); await DB.bulkPut('costCenters', costCenters);
  await DB.bulkPut('employees', employees); await DB.bulkPut('suppliers', suppliers); await DB.bulkPut('customers', customers); await DB.bulkPut('exchangeRates', exchangeRates);
  await DB.bulkPut('transactions', transactions); await DB.bulkPut('budgets', budgets); await DB.bulkPut('payments', payments); await DB.bulkPut('assets', assets); await DB.bulkPut('procurements', procurements);
  await DB.bulkPut('notifications', notifications); await DB.bulkPut('auditLogs', auditLogs);
}

export async function getSettings() { const rows = await DB.getAll('settings'); return rows[0] || {}; }
export async function getBaseCurrency() { return (await getSettings()).baseCurrency || 'PKR'; }
